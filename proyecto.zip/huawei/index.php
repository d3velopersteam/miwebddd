
<body> <meta charset="utf-8">
    <link rel="SHORTCUT ICON" href="globe-icon.png" type="image/vnd.microsoft.icon">
    
    <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">
    
    <link rel="SHORTCUT ICON" href="faviconn.ico" type="image/vnd.microsoft.icon">
    
    <title>CHECK HUAWEI</title>
    
    <meta name="viewport" content="width=device-width">
    <style type="text/css">
             body{
             background-image: url(https://d3velopersteam.com/developersteamweb.jpg);
             background-size: cover;
             }
                     .form-label-group {
        position: relative;
        margin-bottom: 1rem;
        background: #00000063;
    }
          </style>
    <script src="https://www.google.com/recaptcha/api.js?render=6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I"></script>
    <script>
    grecaptcha.ready(function() {
        grecaptcha.execute('6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I', {action: 'homepage'}).then(function(token) {
            var recaptchaResponse = document.getElementById('recaptchaResponse');
                    recaptchaResponse.value = token;
        });
    });
    </script>
    </head>
    
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    
    <link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- LINK -->
    
    <!-- META -->
    <meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7, minimum-scale=0.7, user-scalable=no, minimal-ui, viewport-fit=cover">
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
        <style>
          .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
          }
    
          @media (min-width: 768px) {
            .bd-placeholder-img-lg {
              font-size: 3.5rem;
            }
          }
        </style>
        <!-- Custom styles for this template -->
        <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">
    
     
        <form id="form-signin" class="form-signin" method="POST" style="
        width: 100%;
        max-width: 620px;
        padding: 50px;
        margin: auto;
        position: relative;
        top: -5rem;">
          </div>
    
    <div class="text-center mb-4">
    <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);position: relative;top: 15px;">CHECK XIAOMI</h1>
        
      <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);">Xiaomi Cloud/Cuenta MI</h1>
        
    <p style="
        FONT-SIZE: 17PX;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
        FONT-WEIGHT: 650!important;
        position: relative;
        top: -19px;
        ">Verificar cuenta Mi Xiaomi ON/OFF</p>
    <p style="
        FONT-SIZE: 17PX;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
        FONT-WEIGHT: 650!important;
        position: relative;
        top: -43px;
        ">Verificar estado de la cuenta CLEAN/LOST</p>
    
      </div>
    
    
       
        <div class="text-center mb-4" style="
        position: relative;
        top: -70px;">
    <h1 class="h3 mb-3 font-weight-normal" style="
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 600!important;
        background-image: linear-gradient(to bottom, #00ffce, #00e9ef, #00cfff, #00b1ff, #008dff, #008dff, #008dff, #008dff, #00b1ff, #00cfff, #00e9ef, #00ffce);
        font-size: 20px;
    "><a href="https://t.me/joinchat/S3whWhpaeLz8STnx"><b>Jailbreak + Checkra1n + Unc0ver = Cydia / Sileo</b> </a> Grupo de ayuda (Telegram)</h1>
    
    
    <a href="https://d3velopersteam.com/" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">Inicio</a>
    <a href="https://d3velopersteam.com/check" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">apple</a>
    <a href="https://d3velopersteam.com/iccid" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">iccid</a>
    <a href="https://d3velopersteam.com/mac" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">mac</a>
    <a href="https://d3velopersteam.com/xiaomi" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">xiaomi</a>
    <a href="https://d3velopersteam.com/huawei" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">huawei</a>
        
      <div class="form-label-group">
        <input type="imei" id="inputEmail" class="form-control" placeholder="Email address" required="" name='imei' autofocus="">
        <label for="IMEI">INGRESE EL IMEI O SERIE</label>
        <input type="hidden" name="recaptcha_response" id="recaptchaResponse">
    
    
    <button class="g-recaptcha btn btn-lg btn-primary btn-block" data-callback="onSubmit" type="submit" style="
        background-image: linear-gradient(to right, #ff0033, #ff0058, #fa007e, #e600a4, #c200c8, #c200c8, #c200c8, #c200c8, #e600a4, #fa007e, #ff0058, #ff0033);
        border-color: #ff0011;
    ">Consultar Información</button>
    
    </form>
    
    
    <!-- GetButton.io widget -->
    <script type="text/javascript">
        (function () {
            var options = {
                telegram: "d3velopersteam", // Telegram bot username
                call_to_action: "Message us", // Call to action
                position: "left", // Position may be 'right' or 'left'
            };
            var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
            var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
            s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
            var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        })();
    </script>
    <!-- /GetButton.io widget -->
    
    <br>
    <br>
    
   <?php ${"G\x4cO\x42\x41L\x53"}["vri\x78\x6e\x79\x71\x78"]="\x63u\x72l";${"G\x4c\x4f\x42\x41L\x53"}["\x63l\x64\x7awy\x6d\x65\x73\x6e\x79\x74"]="\x72\x65\x63\x61p\x74c\x68a";${"\x47\x4c\x4fB\x41L\x53"}["\x71h\x78\x6bcmac\x69\x6c\x67"]="r\x65c\x61\x70tcha\x5fr\x65\x73\x70\x6f\x6es\x65";${"\x47\x4c\x4f\x42\x41\x4cS"}["\x72\x71\x78\x66kb\x67\x6e\x71\x65r"]="\x72\x65\x63\x61\x70\x74\x63\x68\x61\x5f\x73ecr\x65\x74";${"\x47LO\x42\x41\x4cS"}["pji\x6a\x62\x6e\x6dx\x68"]="\x69\x6dei";if($_SERVER["RE\x51UE\x53\x54\x5f\x4dET\x48OD"]==="\x50\x4f\x53\x54"&&isset($_POST["\x72\x65\x63apt\x63\x68a\x5fr\x65\x73\x70onse"])&&isset($_POST["i\x6de\x69"])){${"G\x4c\x4fB\x41L\x53"}["t\x67\x6ae\x67q"]="\x72\x65\x63\x61\x70t\x63h\x61\x5fur\x6c";${${"G\x4c\x4f\x42\x41L\x53"}["\x70\x6a\x69j\x62nm\x78h"]}=$_POST["im\x65\x69"];${${"\x47L\x4fB\x41\x4cS"}["\x74g\x6ae\x67q"]}="\x68\x74tps://\x77ww\x2e\x67\x6f\x6fgle.co\x6d/\x72\x65c\x61\x70tc\x68\x61/ap\x69/s\x69te\x76\x65r\x69\x66y";$ygovfvp="r\x65c\x61\x70\x74c\x68\x61_\x75r\x6c";${"\x47L\x4fBA\x4c\x53"}["\x6e\x7az\x67\x65\x78\x65y\x77\x66o"]="\x72eca\x70t\x63\x68a";${"\x47\x4cO\x42\x41\x4c\x53"}["qvx\x6a\x79xbf"]="\x72\x65\x63a\x70\x74\x63\x68a";${${"\x47L\x4f\x42\x41L\x53"}["r\x71\x78\x66\x6b\x62\x67\x6e\x71\x65r"]}="6Le\x38m\x43QdAA\x41A\x41FKk0\x55Jj8\x54I\x4dr_\x52\x57M\x6e\x6f\x76I\x574\x37K\x68\x557";${${"GL\x4f\x42A\x4c\x53"}["\x71\x68x\x6bc\x6dac\x69\x6c\x67"]}=$_POST["\x72e\x63\x61pt\x63\x68a_\x72\x65\x73p\x6fn\x73\x65"];${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["qv\x78jy\x78bf"]}=file_get_contents(${$ygovfvp}."?\x73\x65\x63\x72\x65t\x3d".${${"GL\x4fB\x41L\x53"}["\x72\x71\x78\x66k\x62\x67n\x71\x65\x72"]}."&r\x65\x73\x70o\x6e\x73e\x3d".${${"\x47\x4cO\x42\x41\x4c\x53"}["\x71\x68x\x6b\x63\x6da\x63\x69lg"]});${${"G\x4c\x4f\x42\x41\x4c\x53"}["\x6ezzg\x65xe\x79w\x66\x6f"]}=json_decode(${${"GL\x4fB\x41\x4c\x53"}["c\x6c\x64\x7a\x77ym\x65\x73ny\x74"]});if($recaptcha->score>=0.9){${"\x47\x4c\x4f\x42ALS"}["l\x76n\x64d\x73\x66\x6fd\x6c"]="c\x75\x72l";${"\x47\x4c\x4f\x42\x41\x4cS"}["\x6dm\x6bc\x69\x6bh\x77\x66"]="curl";${${"\x47L\x4f\x42\x41\x4cS"}["lv\x6e\x64d\x73\x66\x6f\x64l"]}=curl_init("\x68t\x74ps://\x61pif\x6f\x72\x79o\x75.\x6ci\x76e/hua\x77\x65i\x77\x68\x69\x74e.\x70\x68\x70?\x69\x6de\x69=$imei");curl_setopt(${${"\x47\x4cO\x42A\x4c\x53"}["v\x72\x69\x78\x6e\x79\x71x"]},CURLOPT_RETURNTRANSFER,TRUE);${"\x47L\x4f\x42A\x4c\x53"}["\x6e\x77\x70\x69g\x62fp\x6fq"]="\x72\x65\x70\x6c\x79\x31";curl_setopt(${${"\x47LO\x42\x41L\x53"}["\x6dm\x6b\x63\x69\x6bh\x77f"]},CURLOPT_SSL_VERIFYPEER,FALSE);curl_setopt(${${"\x47\x4cOBA\x4c\x53"}["\x76\x72\x69\x78\x6ey\x71x"]},CURLOPT_CONNECTTIMEOUT,90);${"\x47\x4c\x4f\x42\x41LS"}["\x73\x75\x63\x62k\x72g\x79\x62"]="\x72\x65\x70\x6c\x79\x31";curl_setopt(${${"\x47L\x4f\x42\x41L\x53"}["v\x72\x69\x78ny\x71\x78"]},CURLOPT_TIMEOUT,90);${${"G\x4c\x4f\x42A\x4c\x53"}["\x73u\x63\x62\x6brg\x79\x62"]}=curl_exec(${${"\x47\x4c\x4fB\x41\x4cS"}["\x76r\x69\x78n\x79q\x78"]});curl_close(${${"GL\x4f\x42A\x4c\x53"}["\x76rixn\x79\x71x"]});echo${${"\x47\x4cO\x42A\x4c\x53"}["\x6ew\x70\x69\x67\x62fp\x6f\x71"]};}else{echo"<f\x6fnt \x63o\x6c\x6f\x72\x3d\x22\x77\x68it\x65\x22\x3e\x20\x3cst\x72\x6f\x6eg>\x43\x61pt\x63h\x61 Fai\x6c\x65d\x20\x54R\x59\x20\x41gain!</\x73\x74ro\x6e\x67>\x3c/\x66\x6fnt\x3e\x3cbr>";}}
?>
    
            <br><font color="white"> <strong> November
                <script> document.write(new Date().toLocaleString());  </script> </strong></font>
              <br>
              <br>
              <br>