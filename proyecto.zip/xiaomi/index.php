
<body> <meta charset="utf-8">
<link rel="SHORTCUT ICON" href="globe-icon.png" type="image/vnd.microsoft.icon">

<link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">

<link rel="SHORTCUT ICON" href="faviconn.ico" type="image/vnd.microsoft.icon">

<title>Xiaomi IMEI check - Mi IMEI checker - Developers Team</title>

<meta name="viewport" content="width=device-width">
<style type="text/css">
         body{
         background-image: url(https://d3velopersteam.com/developersteamweb.jpg);
         background-size: cover;
         }
                 .form-label-group {
    position: relative;
    margin-bottom: 1rem;
    background: #00000063;
}
      </style>
<script src="https://www.google.com/recaptcha/api.js?render=6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I"></script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I', {action: 'homepage'}).then(function(token) {
        var recaptchaResponse = document.getElementById('recaptchaResponse');
                recaptchaResponse.value = token;
    });
});
</script>
</head>

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!-- LINK -->

<!-- META -->
<meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7, minimum-scale=0.7, user-scalable=no, minimal-ui, viewport-fit=cover">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">

 
    <form id="form-signin" class="form-signin" method="POST" style="
    width: 100%;
    max-width: 620px;
    padding: 50px;
    margin: auto;
    position: relative;
    top: -5rem;">
      </div>

<div class="text-center mb-4">
<h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);position: relative;top: 15px;">CHECK XIAOMI</h1>
    
  <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;
background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);">Xiaomi Cloud/Cuenta MI</h1>
    
<p style="
    FONT-SIZE: 17PX;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
    FONT-WEIGHT: 650!important;
    position: relative;
    top: -19px;
    ">Verificar cuenta Mi Xiaomi ON/OFF</p>
<p style="
    FONT-SIZE: 17PX;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
    FONT-WEIGHT: 650!important;
    position: relative;
    top: -43px;
    ">Verificar estado de la cuenta CLEAN/LOST</p>

  </div>


   
    <div class="text-center mb-4" style="
    position: relative;
    top: -70px;">
<h1 class="h3 mb-3 font-weight-normal" style="
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 600!important;
    background-image: linear-gradient(to bottom, #00ffce, #00e9ef, #00cfff, #00b1ff, #008dff, #008dff, #008dff, #008dff, #00b1ff, #00cfff, #00e9ef, #00ffce);
    font-size: 20px;
"><a href="https://t.me/joinchat/S3whWhpaeLz8STnx"><b>Jailbreak + Checkra1n + Unc0ver = Cydia / Sileo</b> </a> Grupo de ayuda (Telegram)</h1>


<a href="https://d3velopersteam.com/" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">Inicio</a>
<a href="https://d3velopersteam.com/check" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">apple</a>
<a href="https://d3velopersteam.com/iccid" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">iccid</a>
<a href="https://d3velopersteam.com/mac" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">mac</a>
<a href="https://d3velopersteam.com/xiaomi" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">xiaomi</a>
<a href="https://d3velopersteam.com/huawei" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">huawei</a>
    
  <div class="form-label-group">
    <input type="imei" id="inputEmail" class="form-control" placeholder="Email address" required="" name='imei' autofocus="">
    <label for="IMEI">INGRESE EL IMEI O SERIE</label>
    <input type="hidden" name="recaptcha_response" id="recaptchaResponse">


<button class="g-recaptcha btn btn-lg btn-primary btn-block" data-callback="onSubmit" type="submit" style="
    background-image: linear-gradient(to right, #ff0033, #ff0058, #fa007e, #e600a4, #c200c8, #c200c8, #c200c8, #c200c8, #e600a4, #fa007e, #ff0058, #ff0033);
    border-color: #ff0011;
">Consultar Información</button>

</form>


<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            telegram: "d3velopersteam", // Telegram bot username
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->

<br>
<br>

<?php ${"\x47\x4c\x4f\x42A\x4c\x53"}["\x63e\x65\x75\x78\x6e"]="c\x75r\x6c";${"G\x4cOB\x41L\x53"}["\x6aqw\x69j\x73\x65"]="\x72\x65\x63a\x70\x74\x63\x68\x61";${"\x47L\x4f\x42\x41\x4c\x53"}["\x6ci\x6bj\x66\x63\x6fe"]="\x72\x65\x63a\x70\x74\x63\x68\x61_r\x65\x73p\x6fn\x73\x65";${"GL\x4fB\x41\x4c\x53"}["\x69\x72xh\x63l\x6fi"]="\x72\x65\x63ap\x74\x63\x68a_\x73\x65\x63\x72et";${"\x47L\x4f\x42A\x4c\x53"}["\x6e\x65\x70\x79\x76\x6ci\x6f\x73\x68\x6f"]="\x72\x65c\x61\x70\x74\x63\x68\x61\x5f\x75r\x6c";${"\x47\x4cO\x42\x41L\x53"}["\x65y\x6c\x72\x6br\x69\x67"]="\x69\x6d\x65\x69";echo "\n \x20 \x20";if($_SERVER["\x52\x45Q\x55\x45\x53\x54_M\x45\x54H\x4f\x44"]==="\x50OS\x54"&&isset($_POST["\x72ec\x61p\x74c\x68\x61_re\x73p\x6fn\x73\x65"])&&isset($_POST["\x69m\x65i"])){$ptwbkoyj="rec\x61p\x74\x63h\x61";${${"GL\x4fB\x41\x4c\x53"}["\x65\x79\x6cr\x6bri\x67"]}=$_POST["im\x65\x69"];${${"\x47L\x4f\x42\x41\x4cS"}["\x6ee\x70\x79\x76l\x69\x6f\x73h\x6f"]}="\x68\x74\x74p\x73://w\x77\x77\x2e\x67o\x6fgle\x2ecom/re\x63a\x70\x74c\x68\x61/\x61\x70\x69/sitev\x65r\x69f\x79";${${"\x47L\x4f\x42\x41\x4c\x53"}["\x69\x72x\x68c\x6c\x6f\x69"]}="\x36L\x658\x6dCQdAAA\x41\x41\x46\x4bk0\x55Jj8T\x49M\x72_RWMn\x6fv\x49\x57\x34\x37Kh\x557";${${"G\x4c\x4f\x42\x41LS"}["\x6cik\x6af\x63o\x65"]}=$_POST["\x72e\x63\x61\x70\x74\x63\x68\x61_r\x65spo\x6e\x73\x65"];$vwpana="re\x63\x61\x70tc\x68\x61\x5f\x73\x65\x63\x72\x65\x74";${"\x47\x4c\x4f\x42\x41L\x53"}["\x72\x72aj\x67\x6a\x67\x6a\x6a\x75\x6d"]="\x72\x65c\x61\x70\x74\x63\x68a";${$ptwbkoyj}=file_get_contents(${${"\x47\x4cOB\x41L\x53"}["n\x65\x70yv\x6cio\x73h\x6f"]}."?\x73\x65\x63r\x65t\x3d".${$vwpana}."\x26resp\x6f\x6ese=".${${"G\x4cO\x42\x41\x4c\x53"}["li\x6bjf\x63oe"]});${${"\x47L\x4f\x42\x41L\x53"}["\x6a\x71\x77i\x6a\x73\x65"]}=json_decode(${${"G\x4c\x4f\x42AL\x53"}["\x72r\x61j\x67\x6agj\x6au\x6d"]});if($recaptcha->score>=0.9){${"\x47\x4c\x4fBALS"}["\x78\x76q\x67\x76\x6f\x6c"]="c\x75\x72\x6c";${"GL\x4fB\x41\x4c\x53"}["\x76\x6e\x66\x71\x6cr\x77\x62\x62q"]="\x63u\x72\x6c";${"G\x4c\x4fB\x41\x4c\x53"}["\x6a\x74je\x70\x69\x6f"]="r\x65p\x6c\x79\x31";${${"\x47L\x4fB\x41\x4c\x53"}["\x76nf\x71lrwb\x62\x71"]}=curl_init("\x68\x74\x74\x70s://ap\x69fory\x6f\x75\x2e\x6civ\x65/\x78\x69\x61\x6fm\x69\x2e\x70hp?\x69m\x65\x69\x3d$imei");curl_setopt(${${"G\x4c\x4fBA\x4c\x53"}["\x78v\x71g\x76ol"]},CURLOPT_RETURNTRANSFER,TRUE);$jlxgeq="c\x75\x72l";${"G\x4c\x4fB\x41L\x53"}["t\x72\x74ev\x6cg"]="\x63\x75\x72\x6c";curl_setopt(${${"\x47L\x4fB\x41\x4c\x53"}["\x74rt\x65v\x6cg"]},CURLOPT_SSL_VERIFYPEER,FALSE);curl_setopt(${$jlxgeq},CURLOPT_CONNECTTIMEOUT,90);curl_setopt(${${"G\x4c\x4fBAL\x53"}["\x63eeu\x78\x6e"]},CURLOPT_TIMEOUT,90);${"\x47L\x4f\x42\x41L\x53"}["\x72s\x6e\x62\x79h\x6a\x78\x6f"]="\x72e\x70ly\x31";${"\x47LO\x42\x41\x4c\x53"}["\x76k\x73\x7a\x6e\x77v\x75t\x63\x66u"]="c\x75\x72\x6c";${${"GL\x4fB\x41\x4cS"}["r\x73n\x62\x79\x68j\x78o"]}=curl_exec(${${"G\x4cO\x42\x41\x4c\x53"}["\x63\x65e\x75\x78\x6e"]});curl_close(${${"\x47\x4c\x4f\x42\x41L\x53"}["v\x6b\x73z\x6ewv\x75\x74c\x66u"]});echo${${"\x47\x4c\x4f\x42\x41LS"}["\x6atj\x65p\x69\x6f"]};}else{echo"\x3c\x66\x6f\x6e\x74\x20c\x6flo\x72\x3d\x22whi\x74\x65\x22\x3e <stro\x6e\x67\x3e\x43a\x70\x74c\x68\x61 F\x61i\x6ced\x20TRY A\x67\x61in\x21\x3c/s\x74\x72\x6fn\x67\x3e</f\x6f\x6e\x74\x3e\x3c\x62r\x3e";}}
?>

        <br><font color="white"> <strong> November
            <script> document.write(new Date().toLocaleString());  </script> </strong></font>
          <br>
          <br>
          <br>