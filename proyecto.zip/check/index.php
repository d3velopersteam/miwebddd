<body> <meta charset="utf-8">
<style>
 {
    margin: 0;
    font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #ffffff;
    text-align: left;
    background-color: #fff;
}
        .form-label-group {
    position: relative;
    margin-bottom: 1rem;
    background: #00000063;
}
</style>
<script src="https://www.google.com/recaptcha/api.js?render=6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I"></script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I', {action: 'homepage'}).then(function(token) {
        var recaptchaResponse = document.getElementById('recaptchaResponse');
                recaptchaResponse.value = token;
    });
});
</script>
</head>

<link rel="SHORTCUT ICON" href="globe-icon.png" type="image/vnd.microsoft.icon">

<link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">

<link rel="SHORTCUT ICON" href="faviconn.ico" type="image/vnd.microsoft.icon">
<title>Check IMEI iPhone or Serial Apple FREE  Developers Team</title>

<meta name="viewport" content="width=device-width">
<style type="text/css">
         body{
         background-image: url(https://d3velopersteam.com/developersteamweb.jpg);
         background-size: cover;
         }
      </style>

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!-- LINK -->

<!-- META -->
<meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7, minimum-scale=0.7, user-scalable=no, minimal-ui, viewport-fit=cover">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">


    <form id="form-signin" class="form-signin" method="POST" style="
    width: 100%;
    max-width: 620px;
    padding: 50px;
    margin: auto;
    position: relative;
    top: -5rem;">
      </div>

<div class="text-center mb-4">
<h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);position: relative;top: 15px;">CHECK IMEI/SN</h1>

  <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;
background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);">iPhone/iPad/iPod/iWatch</h1>

<p style="
    FONT-SIZE: 17PX;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
    FONT-WEIGHT: 650!important;
    position: relative;
    top: -20px;
    ">CHECK ON/OFF - CLEAN/LOST - GSM/MEID</p>
<p style="
    FONT-SIZE: 17PX;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
    FONT-WEIGHT: 650!important;
    position: relative;
    top: -44px;
    ">El Check gsm/meid solo es valido con el imei.</p>
  </div>



    <div class="text-center mb-4" style="
    position: relative;
    top: -70px;">
<h1 class="h3 mb-3 font-weight-normal" style="
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 600!important;
    background-image: linear-gradient(to bottom, #00ffce, #00e9ef, #00cfff, #00b1ff, #008dff, #008dff, #008dff, #008dff, #00b1ff, #00cfff, #00e9ef, #00ffce);
    font-size: 20px;
"><a href="https://t.me/joinchat/S3whWhpaeLz8STnx"><b>Jailbreak + Checkra1n + Unc0ver = Cydia / Sileo</b> </a> Grupo de ayuda (Telegram)</h1>


<a href="https://d3velopersteam.com/" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">Inicio</a>
<a href="https://d3velopersteam.com/check" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">apple</a>
<a href="https://d3velopersteam.com/iccid" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">iccid</a>
<a href="https://d3velopersteam.com/mac" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">mac</a>
<a href="https://d3velopersteam.com/xiaomi" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">xiaomi</a>
<a href="https://d3velopersteam.com/huawei" class="btn btn-danger" data-role="button" style="
    background-color: #ff0075;
    border-color: #ff0075;">huawei</a>


  <div class="form-label-group">
    <input type="imei" id="inputEmail" class="form-control" placeholder="Email address" required="" name='imei' autofocus="">
    <label for="IMEI">INGRESE EL IMEI O SERIE</label>
    <input type="hidden" name="recaptcha_response" id="recaptchaResponse">


<button class="g-recaptcha btn btn-lg btn-primary btn-block" data-callback="onSubmit" type="submit" style="
    background-image: linear-gradient(to right, #ff0033, #ff0058, #fa007e, #e600a4, #c200c8, #c200c8, #c200c8, #c200c8, #e600a4, #fa007e, #ff0058, #ff0033);
    border-color: #ff0011;
">Consultar Informaci&oacute;n</button>

</form>


<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            telegram: "d3velopersteam", // Telegram bot username
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->

<br>
<br>

<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recaptcha_response']) && isset($_POST['imei'])) {
    $imei = $_POST['imei'];

    // Build POST request:
    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptcha_secret = '6Le8mCQdAAAAAFKk0UJj8TIMr_RWMnovIW47KhU7';
    $recaptcha_response = $_POST['recaptcha_response'];

    // Make and decode POST request:
    $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
    $recaptcha = json_decode($recaptcha);

    // Take action based on the score returned:
    if ($recaptcha->score >= 0.9) {



    $curl = curl_init ("https://apiforyou.live/d3v.php?imei=$imei");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 90);
    curl_setopt($curl, CURLOPT_TIMEOUT, 90);
    $reply = curl_exec($curl);
    curl_close($curl);






        echo '<img src="https://km.support.apple.com/resources/sites/APPLE/content/live/IMAGES/0/IM148/en_US/iphonefamily-240.png" alt="Girl in a jacket" width="120" height="120"><br>';



    echo "<font color='white'> <strong>$reply</strong></font><br>";

    } else {

        echo "<font color='white'> <strong>Captcha Failed TRY Again!</strong></font><br>";
    }




}



?>
