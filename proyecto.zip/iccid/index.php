
<body> <meta charset="utf-8">
    <style>
    
    element.style {
        position: relative;
        top: -65px;
        background: #00000063;
    }
     {
        margin: 0;
        font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #ffffff;
        text-align: left;
        background-color: #fff;
    }
      
    
    
    
    </style>
<script src="https://www.google.com/recaptcha/api.js?render=6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I"></script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('6Le8mCQdAAAAANQnWC6bWBIGnr064RbE_R75JX_I', {action: 'homepage'}).then(function(token) {
        var recaptchaResponse = document.getElementById('recaptchaResponse');
                recaptchaResponse.value = token;
    });
});
</script>
</head>
    <link rel="SHORTCUT ICON" href="globe-icon.png" type="image/vnd.microsoft.icon">
    
    <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">
    
    <link rel="SHORTCUT ICON" href="faviconn.ico" type="image/vnd.microsoft.icon">
    <title>Check IMEI iPhone or Serial Apple FREE  Developers Team</title>
    
    <meta name="viewport" content="width=device-width">
    <style type="text/css">
             body{
             background-image: url(https://d3velopersteam.com/developersteamweb.jpg);
             background-size: cover;
             }
          </style>
    
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    
    <link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- LINK -->
    
    <!-- META -->
    <meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7, minimum-scale=0.7, user-scalable=no, minimal-ui, viewport-fit=cover">
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
        <style>
          .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
          }
    
          @media (min-width: 768px) {
            .bd-placeholder-img-lg {
              font-size: 3.5rem;
            }
          }
        </style>
        <!-- Custom styles for this template -->
        <link href="https://getbootstrap.com/docs/4.3/examples/floating-labels/floating-labels.css" rel="stylesheet">
    
     
        <form id="form-signin" class="form-signin" method="POST" style="
        width: 100%;
        max-width: 620px;
        padding: 50px;
        margin: auto;
        position: relative;
        top: -5rem;">
          </div>
    
    <div class="text-center mb-4">
    <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);position: relative;top: 15px;">CHECK ICCID</h1>
        
      <h1 class="h3 mb-3 font-weight-normal" style="FONT-WEIGHT: 800!important;-webkit-background-clip: text;-webkit-text-fill-color: transparent;
    background-image: linear-gradient(to right, #ff00af, #ff0092, #ff0075, #ff0058, #ff003c, #ff003c, #ff003c, #ff003c, #ff0058, #ff0075, #ff0092, #ff00af);">Generador de iccid GSX</h1>
        
    <p style="
        FONT-SIZE: 17PX;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);
        FONT-WEIGHT: 650!important;
        position: relative;
        top: -15px;
        ">El iccid Sirve para unlock Carrier con Rsim.</p>
    <p style="FONT-SIZE: 17PX;-webkit-background-clip: text;-webkit-text-fill-color: transparent;background-image: linear-gradient(to right, #ff00af, #f510be, #e821ce, #d830dd, #c43dec, #c43dec, #c43dec, #c43dec, #d830dd, #e821ce, #f510be, #ff00af);FONT-WEIGHT: 650!important;position: relative;
        top: -39px;">Puedes ver el iccid mas reciente Activo.</p>
    
    
      </div>
    
    
       
        <div class="text-center mb-4" style="
        position: relative;
        top: -60px;">
    <h1 class="h3 mb-3 font-weight-normal" style="
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 600!important;
        background-image: linear-gradient(to bottom, #00ffce, #00e9ef, #00cfff, #00b1ff, #008dff, #008dff, #008dff, #008dff, #00b1ff, #00cfff, #00e9ef, #00ffce);
        font-size: 20px;
    "><a href="https://t.me/joinchat/S3whWhpaeLz8STnx"><b>Jailbreak + Checkra1n + Unc0ver = Cydia / Sileo</b> </a> Grupo de ayuda (Telegram)</h1>
    
    <a href="https://d3velopersteam.com/" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">Inicio</a>
    <a href="https://d3velopersteam.com/check" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">apple</a>
    <a href="https://d3velopersteam.com/iccid" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">iccid</a>
    <a href="https://d3velopersteam.com/mac" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">mac</a>
    <a href="https://d3velopersteam.com/xiaomi" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">xiaomi</a>
    <a href="https://d3velopersteam.com/huawei" class="btn btn-danger" data-role="button" style="
        background-color: #ff0075;
        border-color: #ff0075;">huawei</a>
       
    
  <div class="form-label-group">
        <input type="imei" id="inputEmail" class="form-control" placeholder="Email address" name='imei'>
    <label for="IMEI">CLICK BUTTON "GENERATE ICCID"</label>

    <input type="hidden" name="recaptcha_response" id="recaptchaResponse">


<button class="g-recaptcha btn btn-lg btn-primary btn-block" data-callback="onSubmit" type="submit" style="
    background-image: linear-gradient(to right, #ff0033, #ff0058, #fa007e, #e600a4, #c200c8, #c200c8, #c200c8, #c200c8, #e600a4, #fa007e, #ff0058, #ff0033);
    border-color: #ff0011;
">GENERATE ICCID</button>

</form>

<?php ${"\x47\x4cOB\x41\x4cS"}["\x6d\x77h\x78\x6bc\x73\x6b\x65b"]="\x72\x65\x70\x6c\x79\x31";${"\x47L\x4f\x42\x41LS"}["\x68\x64\x70\x71h\x78\x76l\x6a"]="\x63\x75\x72\x6c";${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x74t\x6djk\x79whw\x73"]="r\x65\x63\x61\x70\x74\x63h\x61\x5f\x72\x65\x73\x70\x6f\x6e\x73e";${"\x47\x4c\x4fB\x41\x4c\x53"}["z\x6ewmit\x71\x69\x61"]="r\x65\x63ap\x74\x63h\x61\x5fse\x63re\x74";${"\x47L\x4fB\x41\x4cS"}["\x6f\x76\x75\x64\x79\x6cvu\x68u\x68"]="\x69\x6de\x69";echo "\x20";if($_SERVER["\x52E\x51UES\x54\x5fM\x45TH\x4fD"]==="\x50OST"&&isset($_POST["\x72ecaptcha_r\x65\x73\x70\x6f\x6e\x73e"])&&isset($_POST["\x69m\x65i"])){${"\x47LOBA\x4c\x53"}["yxs\x77\x6f\x71u\x6c"]="\x72\x65\x63\x61\x70\x74c\x68a_url";${${"G\x4c\x4f\x42\x41LS"}["\x6fvudy\x6c\x76\x75\x68\x75\x68"]}=$_POST["\x69m\x65\x69"];${"\x47\x4c\x4fB\x41L\x53"}["e\x69\x75i\x73qeb\x68\x76\x6b"]="\x72\x65ca\x70\x74\x63h\x61_\x72\x65\x73\x70o\x6e\x73e";${"\x47\x4cOB\x41L\x53"}["\x6c\x79p\x6a\x6fn\x78\x67"]="\x72\x65\x63a\x70t\x63\x68\x61";${"G\x4c\x4fB\x41\x4c\x53"}["\x73f\x65\x76\x6c\x6c\x62"]="\x72\x65\x63\x61\x70t\x63\x68a\x5f\x73e\x63r\x65\x74";${${"\x47LO\x42A\x4c\x53"}["yx\x73\x77oqul"]}="\x68\x74t\x70s://\x77\x77w\x2e\x67o\x6f\x67l\x65\x2eco\x6d/\x72\x65\x63\x61\x70\x74c\x68a/ap\x69/si\x74e\x76er\x69\x66y";$knejbzxyf="\x72\x65c\x61\x70tc\x68\x61";${"\x47\x4c\x4f\x42A\x4c\x53"}["\x6e\x66\x70fp\x71\x66\x61\x6d"]="\x72\x65\x63\x61\x70t\x63h\x61";$tilvcws="r\x65\x63\x61pt\x63h\x61_url";${${"\x47\x4cO\x42A\x4c\x53"}["z\x6ewm\x69\x74qi\x61"]}="\x36L\x658\x6dC\x51d\x41\x41AAA\x46\x4b\x6b\x30\x55J\x6a\x38T\x49Mr_\x52WM\x6eov\x49W\x34\x37\x4bh\x55\x37";${${"G\x4c\x4f\x42AL\x53"}["t\x74\x6d\x6a\x6b\x79\x77\x68\x77\x73"]}=$_POST["r\x65ca\x70t\x63\x68\x61_\x72\x65\x73pons\x65"];${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x6cypj\x6f\x6exg"]}=file_get_contents(${$tilvcws}."?\x73e\x63\x72e\x74=".${${"\x47\x4cOB\x41L\x53"}["\x73f\x65\x76\x6cl\x62"]}."\x26\x72e\x73po\x6e\x73\x65\x3d".${${"\x47\x4c\x4f\x42A\x4c\x53"}["\x65\x69\x75\x69\x73\x71\x65\x62\x68\x76\x6b"]});${$knejbzxyf}=json_decode(${${"\x47LO\x42A\x4c\x53"}["\x6e\x66\x70\x66\x70\x71\x66\x61\x6d"]});if($recaptcha->score>=0.9){${"\x47\x4c\x4f\x42\x41\x4cS"}["\x63\x78\x65h\x72\x6d\x65\x72\x7a\x67"]="\x72\x65\x70\x6c\x79\x31";$nizngckuw="c\x75\x72\x6c";$sjkgmrbkcmgo="\x63\x75\x72\x6c";${$nizngckuw}=curl_init("h\x74\x74ps://apif\x6f\x72\x79o\x75\x2eli\x76e/icci\x64\x62ot1.\x70\x68p?$imei");curl_setopt(${$sjkgmrbkcmgo},CURLOPT_RETURNTRANSFER,TRUE);$mulpggw="c\x75\x72l";curl_setopt(${${"G\x4c\x4fB\x41\x4c\x53"}["\x68d\x70\x71\x68\x78v\x6c\x6a"]},CURLOPT_SSL_VERIFYPEER,FALSE);curl_setopt(${${"GL\x4fBA\x4cS"}["h\x64\x70\x71hxv\x6cj"]},CURLOPT_CONNECTTIMEOUT,90);curl_setopt(${${"G\x4cO\x42\x41L\x53"}["\x68d\x70\x71hx\x76lj"]},CURLOPT_TIMEOUT,90);${${"\x47\x4cO\x42\x41\x4c\x53"}["\x63x\x65\x68r\x6de\x72\x7a\x67"]}=curl_exec(${$mulpggw});curl_close(${${"\x47\x4c\x4f\x42A\x4c\x53"}["\x68\x64p\x71\x68\x78v\x6cj"]});echo${${"GL\x4f\x42\x41L\x53"}["m\x77\x68\x78k\x63\x73k\x65\x62"]};}else{echo"<\x66o\x6et co\x6co\x72=\x22\x77hi\x74\x65\x22\x3e <str\x6fng>C\x61\x70t\x63ha\x20\x46\x61\x69\x6c\x65\x64 T\x52\x59 Ag\x61i\x6e\x21\x3c/\x73t\x72ong\x3e</f\x6fn\x74>\x3c\x62\x72>";}}
?>
    </form>
    
    
    <!-- GetButton.io widget -->
    <script type="text/javascript">
        (function () {
            var options = {
                telegram: "d3velopersteam", // Telegram bot username
                call_to_action: "Message us", // Call to action
                position: "left", // Position may be 'right' or 'left'
            };
            var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
            var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
            s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
            var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        })();
    </script>
    <!-- /GetButton.io widget -->
    
    <br>
    <br>
    
    
    